﻿using UnityEngine;
using System.Collections;

public class BrickBehavior : MonoBehaviour {
    public TextMesh scoretext;
    public int score = 0;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
        scoretext.text = "Score: " + score;
	}

    void OnCollisionEnter2D(Collision2D col) {
        if (col.gameObject.tag == "Brick") {
            score += 100;
            Destroy(col.gameObject);
        }
    }
}
