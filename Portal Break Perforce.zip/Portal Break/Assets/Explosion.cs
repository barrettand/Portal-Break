﻿using UnityEngine;
using System.Collections;

public class Explosion : MonoBehaviour
{
    [SerializeField] float moveIncrement;
    float explosionRad;
    float power;
    [SerializeField]
    float destroyTime;
    public GameObject BOOM;
    GameObject BOOMDOOM;
    // Use this for initialization
    void Start()
    {
        explosionRad = 6;
        power = .2f;
        Destroy(gameObject, destroyTime);
    }

    // Update is called once per frame
    void Update()
    {
        moveBrick();
    }

    void moveBrick()
    {
        float positionX = transform.position.x - moveIncrement;
        Vector3 newPosition = new Vector3(positionX, transform.position.y, transform.position.z);
        transform.position = newPosition;
    }

    void OnCollisionEnter2D(Collision2D col)
    {
       
        if (col.gameObject.tag == "Ball")
        {
            explode();
        }
    }

    void explode()
    {

        BOOMDOOM = (GameObject) Instantiate(BOOM, transform.position, transform.rotation);
        Destroy(this.gameObject);
        Destroy(BOOMDOOM, 1);

    }





}