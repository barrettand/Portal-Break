﻿using UnityEngine;
using System.Collections;

public class BackgroundScroller : MonoBehaviour {



    [SerializeField] float scrollSpeed;

	// Use this for initialization
	void Start () {

	
	}
	
	// Update is called once per frame
	void Update ()
    {
        Vector2 newPosition = new Vector3(transform.position.x - scrollSpeed, transform.position.y);
        transform.position = newPosition;
	}
}
