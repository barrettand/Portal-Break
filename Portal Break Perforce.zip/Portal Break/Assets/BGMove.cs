﻿using UnityEngine;
using System.Collections;

public class BGMove : MonoBehaviour {

    public int offsetX = 2;

    public bool hasarightbuddy = false;
    public bool hasaleftbuddy = false;

    public bool reverseScale = false;

    private float spriteWidth = 0f;
    private Camera cam;
    private Transform myTransform;

    void Awake()
    {
        cam = Camera.main;
        myTransform = transform;
    }

    // Use this for initialization
    void Start () {
        SpriteRenderer sr = GetComponent<SpriteRenderer>();
        spriteWidth = sr.sprite.bounds.size.x;
	}
	
	// Update is called once per frame
	void Update () {
        transform.Translate(-0.025f, 0, 0);
        if (hasaleftbuddy == false && hasarightbuddy == false) {
            float camHorizontalExtend = cam.orthographicSize * Screen.width / Screen.height;
            float edgevisiblepositionRight = (myTransform.position.x + spriteWidth / 2) - camHorizontalExtend;
            float edgevisiblepositionLeft = (myTransform.position.x + spriteWidth / 2) + camHorizontalExtend;

            if (cam.transform.position.x >= edgevisiblepositionRight - offsetX && hasarightbuddy == false) {
                makeNewBuddy(1);
                hasarightbuddy = true;
            }
            else if (cam.transform.position.x <= edgevisiblepositionLeft + offsetX && hasaleftbuddy == false)
            {
                makeNewBuddy(-1);
                hasaleftbuddy = true;
            }
        }
	}
    void makeNewBuddy(int rightOrLeft) {
        Vector3 newPosn = new Vector3(myTransform.position.x + spriteWidth * rightOrLeft, myTransform.position.y, myTransform.position.z);
        Transform newBuddy = Instantiate(myTransform, newPosn, myTransform.rotation) as Transform;
        if (reverseScale == true) {
            newBuddy.localScale = new Vector3(newBuddy.localScale.x * -1, newBuddy.localScale.y, newBuddy.localScale.z);
        }
        newBuddy.parent = myTransform.parent;
        if (rightOrLeft > 0)
        {
            newBuddy.GetComponent<BGMove>().hasaleftbuddy = true;
        }
        else {
            newBuddy.GetComponent<BGMove>().hasarightbuddy = true;
        }
    }
}
