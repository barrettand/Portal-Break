using UnityEngine;
using System.Collections;

public class ScrollingBricks : MonoBehaviour
{
    float moveIncrement;
    bool rocketFlag = false;
    // Use this for initialization
    void Start()
    {
        Destroy(gameObject, 10.0f);
        moveIncrement = .03f; //Controls speed of movement
    }

    // Update is called once per frame
    void Update()
    {
        moveBrick();
        if (rocketFlag) {
            transform.Translate(1f, 0, 0);
        }
    }

    void moveBrick()
    {
        float positionX = transform.position.x - moveIncrement;
        Vector3 newPosition = new Vector3(positionX, transform.position.y, transform.position.z);
        transform.position = newPosition;
    }

    void OnCollisionEnter2D(Collision2D col)
    {
        if (col.gameObject.tag == "Ball" && tag == "Rocket Brick")
        {
            rocketFlag = true;
        }
        if (col.gameObject.tag == "Brick" && tag == "Rocket Brick")
        {
            Destroy(this);
            Destroy(col.gameObject);
        }
        /*float randomX = Random.Range(5, 10);
        float randomY = Random.Range(-5, -10);
        if (col.gameObject.tag == "Ball" && tag == "Brick")
        {
            gameObject.AddComponent<Rigidbody2D>();
            GetComponent<Rigidbody2D>().AddForce(new Vector3(randomX, randomY, 0));
        }
        else if (col.gameObject.tag == "Ball" && tag == "Rocket Brick")
        {
            gameObject.AddComponent<Rigidbody2D>();
            GetComponent<Rigidbody2D>().gravityScale = 0;
            GetComponent<Rigidbody2D>().AddForce(new Vector3(600, 0, 0));
        }
        else if (col.gameObject.tag == "Rocket Brick" && tag == "Brick") {
            gameObject.AddComponent<Rigidbody2D>();
            GetComponent<Rigidbody2D>().AddForce(new Vector3(randomX, randomY, 0));
        }
        else if (col.gameObject.tag == "Rocket Brick" && tag == "Rocket Brick")
        {
            gameObject.AddComponent<Rigidbody2D>();
            GetComponent<Rigidbody2D>().gravityScale = 0;
            GetComponent<Rigidbody2D>().AddForce(new Vector3(600, 0, 0));
        }*/
        if (tag == "Brick")
        {
            Destroy(gameObject, 0.1f);
        }
        if (tag == "Rocket Brick")
        {
            Destroy(gameObject, 1);
        }
    }
}